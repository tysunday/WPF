﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.ComponentModel;
using System.Windows.Markup;
using System.Diagnostics.Eventing.Reader;
using System.Globalization;
namespace hw_16._01._2024_simple_page_localization
{
    internal sealed class DataSource : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }

        private LinearGradientBrush _brush;
        public LinearGradientBrush Brush
        {
            get => _brush;
            set
            {
                if (_brush != value)
                {
                    _brush = value;
                    OnPropertyChanged(new PropertyChangedEventArgs(nameof(Brush)));
                }
            }
        }

        private LinearGradientBrush MakeColorBrushForLocalization()
        {
            LinearGradientBrush brush = new LinearGradientBrush();
            if (Thread.CurrentThread.CurrentUICulture.Name == "ru-RU")
            {

                brush.StartPoint = new Point(0, 0);
                brush.EndPoint = new Point(0, 1);

                brush.GradientStops.Add(new GradientStop(Colors.White, 0.0));
                brush.GradientStops.Add(new GradientStop(Colors.Blue, 0.5));
                brush.GradientStops.Add(new GradientStop(Colors.Red, 1));
            }
            else if (Thread.CurrentThread.CurrentUICulture.Name == "fr-FR")
            {
                brush.StartPoint = new Point(0, 0);
                brush.EndPoint = new Point(1, 1);
                brush.GradientStops.Add(new GradientStop(Colors.Blue, 0.0));
                brush.GradientStops.Add(new GradientStop(Colors.White, 0.5));
                brush.GradientStops.Add(new GradientStop(Colors.Red, 1));
            }
            else if (Thread.CurrentThread.CurrentUICulture.Name == "es-ES")
            {
                brush.StartPoint = new Point(0, 0);
                brush.EndPoint = new Point(0, 1);
                brush.GradientStops.Add(new GradientStop(Colors.Red, 0.0));
                brush.GradientStops.Add(new GradientStop(Colors.Yellow, 0.5));
                brush.GradientStops.Add(new GradientStop(Colors.Red, 1));
            }
            else if (Thread.CurrentThread.CurrentUICulture.Name == "id-ID")
            {

                brush.StartPoint = new Point(0, 0);
                brush.EndPoint = new Point(0, 1);
                brush.GradientStops.Add(new GradientStop(Colors.Red, 0.0));
                brush.GradientStops.Add(new GradientStop(Colors.White, 1));
            }

            return brush;
        }

        public void UpdateBrush()
        {
            Brush = MakeColorBrushForLocalization();
        }
    }
    public partial class MainWindow : Window
    {
        string CurrentCulture = "ru-RU";
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new DataSource();
        }
        private void UpdateUI()
        {
            Main.Content = CommonStrings.Home;
            Services.Content = CommonStrings.Services;
            Excursions.Content = CommonStrings.Excursions;
            History.Content = CommonStrings.History;
            News.Content = CommonStrings.News;
            Contacts.Content = CommonStrings.Contacts;
            MainText.Text = CommonStrings.MainText;
            ((DataSource)DataContext).UpdateBrush();
            LanguageButton.Content = Thread.CurrentThread.CurrentUICulture.Name;
        }

        private void UpdateLocalization()
        {
            if (CurrentCulture == "ru-RU")
                CurrentCulture = "fr-FR";
            else if (CurrentCulture == "fr-FR")
                CurrentCulture = "id-ID";
            else if (CurrentCulture == "id-ID")
                CurrentCulture = "es-ES";
            else if (CurrentCulture == "es-ES")
                CurrentCulture = "ru-RU";
            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(CurrentCulture);
        }

        private void LanguageButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateLocalization();
            UpdateUI();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateUI();
        }
    }
}