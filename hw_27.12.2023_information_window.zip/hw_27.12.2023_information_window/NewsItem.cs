﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw_27._12._2023_information_window
{
    public class NewsItem
    {
        public string Date { get; set; }
        public string ShortDescription { get; set; }
        public string FullDescription { get; set; }
    }
}
