﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hw_27._12._2023_information_window
{
    public class Services
    {
        public string ServiceName { get; set; }
        public string Description { get; set; }
        public int Cost { get; set; }
    }
}
