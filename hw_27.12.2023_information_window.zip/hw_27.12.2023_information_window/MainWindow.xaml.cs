﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using System.Security.Policy;

namespace hw_27._12._2023_information_window
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private BackgroundWorker _bgWorker = new BackgroundWorker();
        private int _workerState;
        public int WorkerState
        {
            get { return _workerState; }
            set
            {
                _workerState = value;
                if (PropertyChanged != null)
                    PropertyChanged(this, new PropertyChangedEventArgs("WorkerState"));
            }
        }
        public MainWindow()
        {
            InitializeComponent();
            _bgWorker.RunWorkerCompleted += _bgWorker_RunWorkerCompleted;

            DataContext = this;
            _bgWorker.DoWork += (s, e) =>
            {
                for (int i = 0; i < 100; i++)
                {
                    System.Threading.Thread.Sleep(10);
                    WorkerState = i;
                }
            };

            NewsListBox.ItemsSource = new List<NewsItem>
            {
                new NewsItem { Date = "2023-01-01", ShortDescription = "Открытие нового отделения природоохранного комплекса", FullDescription = "Природоохранный комплекс 'Белый Лев' рад сообщить о открытии нового отделения, которое будет специализироваться в сохранении редких видов флоры и фауны. Новое отделение предоставит уникальные услуги и возможности для всех природолюбителей." },
                new NewsItem { Date = "2023-02-15", ShortDescription = "Запуск программы восстановления экосистемы", FullDescription = "Мы рады объявить о запуске новой программы восстановления экосистемы, направленной на восстановление и поддержание биоразнообразия в природных резерватах. Присоединяйтесь к нам в этом важном мероприятии для сохранения природы." },
                new NewsItem { Date = "2023-03-10", ShortDescription = "День открытых дверей в природоохранном комплексе", FullDescription = "Приглашаем всех желающих посетить наш природоохранный комплекс 'Белый Лев' в День открытых дверей! У вас будет уникальная возможность ознакомиться с нашей работой, принять участие в экскурсиях и мероприятиях, а также узнать больше о наших природоохранных проектах." }
            };
            string HomeText = "Наша миссия – охрана и сохранение уникальных экосистем и животного мира для будущих поколений. Белый Лев – это не просто природоохранное пространство, это место, где природа и человек сливаются в единое целое.\r\n\r\nО Нас:\r\n\r\nБелый Лев – это уникальный природный комплекс, расположенный в самом сердце живописной природы. Мы гордимся богатством нашей фауны и флоры, предлагая посетителям неповторимый опыт взаимодействия с природой.\r\n\r\nНаши Ценности:\r\n\r\nСохранение Биоразнообразия: Мы посвящены сохранению разнообразия животного и растительного мира. Белый Лев становится домом для множества видов, включая уникальные и редкие.\r\n\r\nЭкологическое Образование: Мы стремимся образовывать общество о важности охраны природы. Наши образовательные программы, экскурсии и мероприятия призваны вдохновлять людей заботиться о окружающей среде.\r\n\r\nУстойчивое Использование Ресурсов: Белый Лев придерживается принципов устойчивого развития, обеспечивая гармонию между человеком и природой. Мы поощряем ответственное использование ресурсов и сбалансированный образ жизни.\r\n\r\nНаши Активности:\r\n\r\nЭкскурсии и Путеводительства: Погрузитесь в мир дикой природы с нашими опытными гидами. Откройте для себя удивительные места и уникальные виды.\r\n\r\nОбразовательные Программы: Присоединяйтесь к нашим образовательным мероприятиям, чтобы углубить свои знания об экосистемах, биоразнообразии и природозащитных усилиях.\r\n\r\nЭкологические Исследования: Мы активно проводим научные исследования для понимания и поддержания баланса в наших экосистемах.\r\n\r\nПрисоединяйтесь к Нам:\r\n\r\nБелый Лев открыт для всех, кто разделяет наше стремление к заботе о природе. Присоединяйтесь к нам в наших усилиях по сохранению этого удивительного мира для будущих поколений.\r\n\r\nСпасибо, что выбрали Белый Лев – ваш партнер в сохранении природы!";
            MainText.Text = HomeText;

            ServicesListBox.ItemsSource = new List<Services>
{
    new Services {ServiceName = "Экологические экскурсии", Description = "Узнайте больше о природных красотах комплекса под руководством опытных гидов.", Cost = 10},
    new Services {ServiceName = "Сбор отходов", Description = "Принимайте активное участие в очистке территории от мусора и поддерживайте чистоту природы.", Cost = 5},
    new Services {ServiceName = "Садоводческие мастер-классы", Description = "Научитесь выращивать свои собственные овощи и цветы под руководством наших экспертов.", Cost = 15},
    new Services {ServiceName = "Фотосафари", Description = "Организуем увлекательные фотосессии в окружении живописных пейзажей и дикой природы.", Cost = 20},
    new Services {ServiceName = "Уроки по выживанию", Description = "Получите навыки выживания в дикой природе от наших профессиональных инструкторов.", Cost = 25},
    new Services {ServiceName = "Птиценаблюдение", Description = "Познакомьтесь с разнообразием местных птиц под руководством орнитологов.", Cost = 12},
    new Services {ServiceName = "Занятия йогой на природе", Description = "Научитесь практиковать йогу, наслаждаясь свежим воздухом и красотой природы.", Cost = 18},
    new Services {ServiceName = "Пикник в лесу", Description = "Наши пикники в окружении природы создадут незабываемую атмосферу отдыха.", Cost = 30}
};

        }

        private void CreateNewNews_Click(object sender, RoutedEventArgs e)
        {
            AddNewsDialog dialog = new AddNewsDialog();
            dialog.ShowDialog();
            NewsItem newNews = new NewsItem
            {
                Date = dialog.SelectedDate,
                ShortDescription = dialog.ShortDescription,
                FullDescription = dialog.FullDescription
            };

            List<NewsItem> newsList = (List<NewsItem>)NewsListBox.ItemsSource;
            NewsListBox.ItemsSource = newsList;
            newsList.Add(newNews);

            NewsListBox.ItemsSource = null;
            NewsListBox.ItemsSource = newsList;
        }
        private void DeleteNewNews_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int selectedNewsIndex = NewsListBox.SelectedIndex;
                List<NewsItem> newsList = (List<NewsItem>)NewsListBox.ItemsSource;
                newsList.RemoveAt(selectedNewsIndex);
                NewsListBox.ItemsSource = null;
                NewsListBox.ItemsSource = newsList;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + '\n' + "*Сначала выберите новость, затем жмите удалить*");
            }
        }
        private void MakeDonation_Click(object sender, RoutedEventArgs e)
        {
            if (!_bgWorker.IsBusy)
            {
                ProgressBarDonation.Visibility = Visibility.Visible;
                _bgWorker.RunWorkerAsync();
            }
            else
                MessageBox.Show("Background worker is already running.");
        }
        private void _bgWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            ProgressBarDonation.Visibility = Visibility.Hidden;

            double money = SliderDonation.Value;
            MessageBox.Show($"Thanks for your donation. {money}$ successfully credited.");
        }
        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            ((Slider)sender).SelectionEnd = e.NewValue;
        }
    }
}
