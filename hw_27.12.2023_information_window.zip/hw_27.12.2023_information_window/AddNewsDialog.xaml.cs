﻿using System;
using System.Windows;

namespace hw_27._12._2023_information_window
{
    public partial class AddNewsDialog : Window
    {
        public string SelectedDate { get; private set; }
        public string ShortDescription { get; private set; }
        public string FullDescription { get; private set; }

        public AddNewsDialog()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            SelectedDate = DatePicker.SelectedDate?.ToString("yyyy-MM-dd");
            ShortDescription = ShortDescriptionTextBox.Text;
            FullDescription = FullDescriptionTextBox.Text;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }
    }
}
