﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using Microsoft.Win32;
using System.Text.RegularExpressions;

namespace hw_03._01._2023_notebook
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();

            DataContext = this;

            SearchMatchCase = false;
            SearchDown = true;
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtEditor = new TextEditor();
            textEditorHolder.Children.Add(txtEditor);
            var layer = System.Windows.Documents.AdornerLayer.GetAdornerLayer(txtEditor);
            SelectionHighlightAdorner txtEditorAdorner = new SelectionHighlightAdorner(txtEditor);
            layer.Add(txtEditorAdorner);

            txtEditor.AcceptsReturn = true;
            txtEditor.AcceptsTab = true;
            txtEditor.TextChanged += txtEditor_TextChanged;

            txtEditor.Focus();
        }

        private void txtEditor_TextChanged(object sender, EventArgs e)
        {
            Dirty = true;
        }
        public TextEditor txtEditor { get; private set; }
    
        public string FilePath { get; private set; }
        public bool Dirty { get; private set; }
        public string FileName
        {
            get
            {
                return string.IsNullOrEmpty(FilePath)
                    ? "Untitled"
                    : System.IO.Path.GetFileName(FilePath);
            }
        }
        public string WindowTitle
        {
            get
            {
                return FileName + " - Notepad.WPF";
            }
        }


        private void NewCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void NewCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (!SaveOnDirty())
                return;

            txtEditor.Text = "";
            FilePath = null;
            Dirty = false;
        }

        private void OpenCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void OpenCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (!SaveOnDirty())
                return;

            OpenFileDialog dlg = new OpenFileDialog()
            {
                Filter = "Text Files |*.txt"
            };
            if (dlg.ShowDialog() == true)
            {
                FilePath = dlg.FileName;
                txtEditor.Text = File.ReadAllText(FilePath);
                Dirty = false;
            }
        }
        private void SaveCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void SaveCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            Save();
        }
        private void SaveAsCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void SaveAsCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            SaveAs();
        }
        private void ExitCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void ExitCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            if (!SaveOnDirty())
                return;

            Application.Current.Shutdown();
        }
        private void Save()
        {
            if (string.IsNullOrEmpty(FilePath))
            {
                SaveAs();
            }
            else
            {
                File.WriteAllText(FilePath, txtEditor.Text);
                Dirty = false;
            }
        }
        private void SaveAs()
        {
            SaveFileDialog dlg = new SaveFileDialog
            {
                Filter = "Text Files|*.txt",
                OverwritePrompt = true
            };
            if (dlg.ShowDialog() == true)
            {
                FilePath = dlg.FileName;
                File.WriteAllText(FilePath, txtEditor.Text);
                Dirty = false;
            }
        }
        private bool SaveOnDirty()
        {
            if (!Dirty)
            {
                return true;
            }

            string name = string.IsNullOrEmpty(FilePath) ? "Untitled" : FilePath;
            MessageBoxResult result = MessageBox.Show(
               "Would you like to save changes to " + name + "?",
               "Notepad.WPF",
               MessageBoxButton.YesNoCancel);
            switch (result)
            {
                case MessageBoxResult.Yes:
                    Save();
                    return !Dirty;
                case MessageBoxResult.No:
                    return true;
                case MessageBoxResult.Cancel:
                    return false;
            }
            return true;
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!SaveOnDirty())
                e.Cancel = true;
        }
        private void DeleteCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = txtEditor.SelectionLength > 0;
        }
        private void DeleteCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            txtEditor.SelectedText = "";
        }
        private void InsertDateTimeCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void InsertDateTimeCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            txtEditor.SelectedText = DateTime.Now.ToString();
        }
        private void FindCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void FindCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            FindWindow dlg = new FindWindow(this, SearchText, SearchMatchCase, SearchDown);
            dlg.ShowDialog();
        }
        private void FindNextCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = !string.IsNullOrEmpty(SearchText);
        }
        private void FindNextCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            FindNext();
        }
        public string SearchText { get; private set; }
        public bool SearchMatchCase { get; private set; }
        public bool SearchDown { get; private set; }
        private void FindNext()
        {
            string text = txtEditor.Text;
            StringComparison comparison = SearchMatchCase
                ? StringComparison.CurrentCulture
                : StringComparison.CurrentCultureIgnoreCase;
            int index;
            if (SearchDown)
            {
                int start = txtEditor.SelectionStart + txtEditor.SelectionLength;
                index = text.IndexOf(SearchText, start, comparison);
            }
            else
            {
                int start = txtEditor.SelectionStart;
                index = text.LastIndexOf(SearchText, start, comparison);
            }
            if (index >= 0)
            {
                txtEditor.SelectionStart = index;
                txtEditor.SelectionLength = SearchText.Length;
            }
            else
            {
                MessageBox.Show(
                    "Cannot find \"" + SearchText + "\"",
                    "Notepad.WPF",
                    MessageBoxButton.OK,
                    MessageBoxImage.Information);
            }
        }
        public void Find(string search, bool matchCase, bool down)
        {
            SearchText = search;
            SearchMatchCase = matchCase;
            SearchDown = down;
            FindNext();
        }
        public string SearchReplace { get; private set; }
        public bool CanReplace(string search, bool matchCase)
        {
            StringComparer comparer = StringComparer.Create(System.Globalization.CultureInfo.CurrentCulture, !matchCase);
            return comparer.Compare(search, txtEditor.SelectedText) == 0;
        }
        public void Replace(string search, string replace, bool matchCase)
        {
            SearchText = search;
            SearchReplace = replace;
            SearchMatchCase = matchCase;
            if (CanReplace(search, matchCase))
            {
                int index = txtEditor.SelectionStart;
                txtEditor.SelectedText = replace;
            }
        }
        public void ReplaceAll(string search, string replace, bool matchCase)
        {
            SearchText = search;
            SearchReplace = replace;
            SearchMatchCase = matchCase;
            txtEditor.Text = Regex.Replace(txtEditor.Text, search, replace, RegexOptions.IgnoreCase);
        }
        private void ReplaceCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }
        private void ReplaceCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            ReplaceWindow dlg = new ReplaceWindow(this, SearchText, SearchReplace, SearchMatchCase);
            dlg.ShowDialog();
        }
    }
}
