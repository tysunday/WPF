﻿using Prism.Commands;
using System;
using System.ComponentModel;
using System.Windows.Media;

namespace hw_23._01._2023_ColorViewer
{
    public class ColorItemViewModel : INotifyPropertyChanged
    {
        private ColorModel _colorModel;
        private string _hexCode;

        public ColorModel ColorModel
        {
            get { return _colorModel; }
            set
            {
                if (_colorModel != value)
                {
                    _colorModel = value;
                    OnPropertyChanged(nameof(ColorModel));
                    UpdateHexCode();
                }
            }
        }

        public string HexCode
        {
            get { return _hexCode; }
            set
            {
                if (_hexCode != value)
                {
                    _hexCode = value;
                    OnPropertyChanged(nameof(HexCode));
                }
            }
        }

        private DelegateCommand _deleteCommand;

        public DelegateCommand DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                {
                    _deleteCommand = new DelegateCommand(Delete);
                }
                return _deleteCommand;
            }
        }

        private void Delete()
        {
            var parentCollection = ColorsViewModel.Colors;
            parentCollection.Remove(this);
        }

        private void UpdateHexCode()
        {
            HexCode = MakeHexCode();
        }

        private string MakeHexCode()
        {
            return string.Format("#{0:X2}{1:X2}{2:X2}{3:X2}",
                     _colorModel.Alpha,
                     _colorModel.Red,
                     _colorModel.Green,
                     _colorModel.Blue);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public ColorViewModel ColorsViewModel { get; set; }
    }
}
