﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace hw_23._01._2023_ColorViewer
{
    public class ColorModel : INotifyPropertyChanged
    {
        private byte _alpha = 255;
        private byte _red = 33;
        private byte _green = 66;
        private byte _blue = 99;

        public byte Alpha
        {
            get { return _alpha; }
            set
            {
                if (_alpha != value)
                {
                    _alpha = value;
                    OnPropertyChanged(nameof(Alpha));
                    OnPropertyChanged(nameof(Color));
                }
            }
        }

        public byte Red
        {
            get { return _red; }
            set
            {
                if (_red != value)
                {
                    _red = value;
                    OnPropertyChanged(nameof(Red));
                    OnPropertyChanged(nameof(Color));
                }
            }
        }

        public byte Green
        {
            get { return _green; }
            set
            {
                if (_green != value)
                {
                    _green = value;
                    OnPropertyChanged(nameof(Green));
                    OnPropertyChanged(nameof(Color));
                }
            }
        }

        public byte Blue
        {
            get { return _blue; }
            set
            {
                if (_blue != value)
                {
                    _blue = value;
                    OnPropertyChanged(nameof(Blue));
                    OnPropertyChanged(nameof(Color));
                }
            }
        }

        public Color Color
        {
            get { return Color.FromArgb(Alpha, Red, Green, Blue); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

}
