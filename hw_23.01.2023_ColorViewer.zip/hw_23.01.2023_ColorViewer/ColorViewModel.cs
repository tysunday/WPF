﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using Prism.Commands;

namespace hw_23._01._2023_ColorViewer
{
    public class ColorViewModel : INotifyPropertyChanged
    {
        private ColorModel _colorModel;

        public ColorModel ColorModel
        {
            get { return _colorModel; }
            set
            {
                if (_colorModel != value)
                {
                    _colorModel = value;
                    OnPropertyChanged(nameof(ColorModel));
                }
            }
        }

        private ObservableCollection<ColorItemViewModel> _colors;
        public ObservableCollection<ColorItemViewModel> Colors
        {
            get { return _colors; }
            set
            {
                if (_colors != value)
                {
                    _colors = value;
                    OnPropertyChanged(nameof(Colors));
                }
            }
        }

        public ColorViewModel()
        {
            _colorModel = new ColorModel();
            Colors = new ObservableCollection<ColorItemViewModel>();

            AddColorCommand = new DelegateCommand(AddColor);
        }
        public DelegateCommand AddColorCommand { get; }

        private void AddColor()
        {
            var colorItemViewModel = new ColorItemViewModel
            {
                ColorModel = new ColorModel
                {
                    Alpha = _colorModel.Alpha,
                    Red = _colorModel.Red,
                    Green = _colorModel.Green,
                    Blue = _colorModel.Blue
                },
                ColorsViewModel = this
            };
            Colors.Add(colorItemViewModel);
        }


        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
