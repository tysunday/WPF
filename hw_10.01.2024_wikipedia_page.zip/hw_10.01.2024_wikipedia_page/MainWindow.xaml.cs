﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;


namespace hw_10._01._2024_wikipedia_page
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            HyperLinkTextBlockLeftSide.Loaded += HyperLinkTextBlock_Loaded;
            string text = File.ReadAllText("RightTextSoprano.txt");
            RichTextBox1.AppendText(text);
            text = File.ReadAllText("MainTextSoprano.txt");
            Run2.Text = text;
        }

        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {
            Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri));
            e.Handled = true;
        }

        private void HyperLinkTextBlock_Loaded(object sender, RoutedEventArgs e)
        {
            foreach (var inline in HyperLinkTextBlockLeftSide.Inlines)
            {
                if (inline is Hyperlink hprlnk)
                {
                    hprlnk.RequestNavigate += Hyperlink_RequestNavigate;
                }
            }

            foreach (var inline in HyperLinkTextBlockUpperSide.Inlines)
            {
                if (inline is Hyperlink hprlnk)
                {
                    hprlnk.RequestNavigate += Hyperlink_RequestNavigate;
                }
            }
        }

        private void MainText_ContextMenuOpening(object sender, ContextMenuEventArgs e)
        {

        }
        private bool IsSelectedTextBold()
        {
            TextSelection selectedText = MainText.Selection;
            if (selectedText != null && !selectedText.IsEmpty)
            {
                object fontWeight = selectedText.GetPropertyValue(TextElement.FontWeightProperty);
                return fontWeight != null && fontWeight.Equals(FontWeights.Bold);
            }
            return false;
        }

        private void MenuItem_Click_Bold(object sender, RoutedEventArgs e)
        {
            TextSelection selectedText = MainText.Selection;
            if (selectedText != null && !selectedText.IsEmpty)
            {
                if (!IsSelectedTextBold())
                    selectedText.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Bold);
                else
                    selectedText.ApplyPropertyValue(TextElement.FontWeightProperty, FontWeights.Normal);
            }
        }

       
        private void MenuItem_Click_Bigger(object sender, RoutedEventArgs e)
        {
            TextSelection selectedText = MainText.Selection;
            if(selectedText != null)
            {
                double currentSize = (double)selectedText.GetPropertyValue(TextElement.FontSizeProperty);
                selectedText.ApplyPropertyValue(TextElement.FontSizeProperty, currentSize + 2);
            }
        }

        private void MenuItem_Click_Smaller(object sender, RoutedEventArgs e)
        {
            TextSelection selectedText = MainText.Selection;
            if (selectedText != null)
            {
                double currentSize = (double)selectedText.GetPropertyValue(TextElement.FontSizeProperty);
                selectedText.ApplyPropertyValue(TextElement.FontSizeProperty, Math.Max(currentSize - 1, 1)); // Для того чтоб не было возможности сделать текст размером = 0.
            }
        }

        private void MenuItem_Click_Color(object sender, RoutedEventArgs e)
        {
            TextSelection selectedText = MainText.Selection;
            if(selectedText != null)
            {
             ColorDialog colorDialog = new ColorDialog();
                if (colorDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                    selectedText.ApplyPropertyValue(TextElement.ForegroundProperty, new SolidColorBrush(Color.FromRgb(colorDialog.Color.R, colorDialog.Color.G, colorDialog.Color.B)));
            }
        }

        private void MenuItem_Click_Italic(object sender, RoutedEventArgs e)
        {
            TextSelection selectedText = MainText.Selection;
            if (selectedText != null)
            {
                FontStyle newStyle = selectedText.GetPropertyValue(TextElement.FontStyleProperty) != null &&
                                     selectedText.GetPropertyValue(TextElement.FontStyleProperty).Equals(FontStyles.Italic)
                    ? FontStyles.Normal
                    : FontStyles.Italic;

                selectedText.ApplyPropertyValue(TextElement.FontStyleProperty, newStyle);
            }
        }

        private void MenuItem_Click_Underlined(object sender, RoutedEventArgs e)
        {
            TextSelection selectedText = MainText.Selection;
            if (selectedText != null)
            {
                TextDecorationCollection currentDecoration = (TextDecorationCollection)selectedText.GetPropertyValue(Inline.TextDecorationsProperty);
                if (currentDecoration == null || currentDecoration.Count == 0)
                    selectedText.ApplyPropertyValue(Inline.TextDecorationsProperty, TextDecorations.Underline);
                
                else
                    selectedText.ApplyPropertyValue(Inline.TextDecorationsProperty, null);
                
            }
        }

    }
}

