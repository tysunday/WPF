﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace hw_19._01._2024_binding_text
{
    public partial class MainWindow : Window, INotifyPropertyChanged
    {

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            PropertyChanged?.Invoke(this, e);
        }
        private string _inputText = string.Empty;
        public string InputText
        {
            get { return _inputText; }
            set
            {
                _inputText = value;
                OnPropertyChanged(new PropertyChangedEventArgs(nameof(InputText)));
                OnPropertyChanged(new PropertyChangedEventArgs(nameof(InputLength)));
            }
        }
        public int InputLength => InputText?.Count() ?? 0;
        public ObservableCollection<string> Items { get; } = new ObservableCollection<string>();
        public int ItemsCount => Items.Count;
        private void AddToList_Click(object sender, RoutedEventArgs e)
        {
            Items.Add(InputText);
            InputText = string.Empty;
            OnPropertyChanged(new PropertyChangedEventArgs(nameof(ItemsCount)));
        }
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }
    }
}
