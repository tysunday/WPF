﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace hw_09._01._2024_graphics_editor
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int diameter = (int)Sizes.small;
        private Brush brushcolor = Brushes.Black;
        private bool ispaint = false;
        private bool iserase = false;
        private enum Sizes
        {
            small = 10,
            medium = 15,
            large= 30
        }
        public MainWindow()
        {
            InitializeComponent();
        }

        private void PaintCircle(Brush circlecolor, Point position)
        {
            Ellipse newEllipse = new Ellipse();
            newEllipse.Fill = circlecolor;
            newEllipse.Width = diameter;
            newEllipse.Height = diameter;
            Canvas.SetTop(newEllipse, position.Y);
            Canvas.SetLeft(newEllipse, position.X);
            DrawingCanvas.Children.Add(newEllipse);
        }

        private void DrawingCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (ispaint)
            {
                Point mouseposition = e.GetPosition(DrawingCanvas);
                PaintCircle(brushcolor, mouseposition);
            }
            if(iserase)
            {
                Point mouseposition = e.GetPosition(DrawingCanvas);
                PaintCircle(brushcolor, mouseposition);
            }
        }

        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            brushcolor = Brushes.Red;
        }

        private void RadioButton_Checked_1(object sender, RoutedEventArgs e)
        {
            brushcolor = Brushes.Blue;
        }

        private void RadioButton_Checked_2(object sender, RoutedEventArgs e)
        {
            brushcolor = Brushes.Black;
        }

        private void RadioButton_Checked_3(object sender, RoutedEventArgs e)
        {
            diameter = (int)Sizes.small;
        }

        private void RadioButton_Checked_4(object sender, RoutedEventArgs e)
        {
            diameter = (int)Sizes.medium;
        }

        private void RadioButton_Checked_5(object sender, RoutedEventArgs e)
        {
            diameter = (int)Sizes.large;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            int count = DrawingCanvas.Children.Count;

            if (count > 0)
                DrawingCanvas.Children.RemoveAt(count - 1);
        }

        private void DrawingCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ispaint = true;
        }

        private void DrawingCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ispaint = false;
        }
    }
}