﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace hw_09._01_2024_change_button_color
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            try
            {
                string filePath = "maintext.txt";
                TextOnPage.Text = File.ReadAllText(filePath);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading the file. {ex.Message}");
            }
            ButtonEvents();
        }

        private void ButtonEvents()
        {
            foreach (var button in StackPanelWithButton.Children)
            {
                if (button is Button btn)
                {
                    btn.MouseEnter += Button_MouseEnter;
                    btn.MouseLeave += Button_MouseLeave;
                }
            }
        }

        private void Button_MouseEnter(object sender, MouseEventArgs e)
        {
            if (sender is Button button)
            {
                button.Background = new RadialGradientBrush
                {
                    GradientStops =
                    {
                        new GradientStop(Colors.DarkRed, 0.2),
                        new GradientStop(Colors.DarkBlue, 1)
                    }
                };
            }
        }
        private void Button_MouseLeave(object sender, MouseEventArgs e)
        {
            if (sender is Button button)
            {
                button.Background = new LinearGradientBrush
                {
                    StartPoint = new Point(0, 0),
                    EndPoint = new Point(1, 1),
                    GradientStops =
                {
                    new GradientStop(Colors.DarkRed, 0.2),
                    new GradientStop(Colors.DarkBlue, 1)
                }
                };
            }
        }
    }
  
}
