﻿using System;
using System.CodeDom;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Windows.Media;

namespace hw_29._01._2024_color_mvvm
{
    public class ColorViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public Color MyСolor
        {
            get
            {
                return ColorModel.GetMyColor(Alpha, Red, Green, Blue);
            }
        }

        ObservableCollection<Color> _colors;
        public ObservableCollection<Color> Colors
        {
            get { return _colors; }
            set { _colors = value; }
        }

        public ICommand AddColorCommand { get; }

        public ColorViewModel()
        {
            Colors = new ObservableCollection<Color>();
            AddColorCommand = new RelayCommand(() =>
                Colors.Add(MyСolor)
            );
        }
        private void UpdateHexCode()
        {
            HexCode = string.Format("#{0:X2}{1:X2}{2:X2}{3:X2}",
                    Alpha, Red, Green, Blue);
        }

        string _hexCode;
        public string HexCode
        {
            get { return _hexCode; }
            set
            {
                if (_hexCode != value)
                {
                    _hexCode = value;
                    OnPropertyChanged(nameof(HexCode));
                }
            }
        }

        private byte _alpha = 255;
        public byte Alpha
        {
            get { return _alpha; }
            set
            {
                if (_alpha != value)
                {
                    _alpha = value;
                    OnPropertyChanged(nameof(MyСolor));
                    OnPropertyChanged(nameof(Alpha));
                }
            }
        }

        private byte _red = 99;
        public byte Red
        {
            get { return _red; }
            set
            {
                if (_red != value)
                {
                    _red = value;
                    OnPropertyChanged(nameof(MyСolor));
                    OnPropertyChanged(nameof(Red));
                }
            }
        }

        private byte _green = 10;
        public byte Green
        {
            get { return _green; }
            set
            {
                if (_green != value)
                {
                    _green = value;
                    OnPropertyChanged(nameof(MyСolor));
                    OnPropertyChanged(nameof(Green));
                }
            }
        }

        private byte _blue = 10;
        public byte Blue
        {
            get { return _blue; }
            set
            {
                if (_blue != value)
                {
                    _blue = value;
                    OnPropertyChanged(nameof(MyСolor));
                    OnPropertyChanged(nameof(Blue));
                }
            }
        }
    }

}