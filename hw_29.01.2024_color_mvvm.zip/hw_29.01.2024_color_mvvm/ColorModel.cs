﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace hw_29._01._2024_color_mvvm
{
    public class ColorModel
    {
        public static Color GetMyColor(byte Alpha, byte Red, byte Green, byte Blue) => Color.FromArgb(Alpha, Red, Green, Blue);

    }
}
