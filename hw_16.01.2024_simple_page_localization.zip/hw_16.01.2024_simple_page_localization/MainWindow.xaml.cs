﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.ComponentModel;

namespace hw_16._01._2024_simple_page_localization
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    ///
    public partial class MainWindow : Window
    {
        string CurrentCulture = "ru";
        public MainWindow()
        {
            InitializeComponent();
        }
        private void UpdateUI()
        {
            Main.Content = CommonStrings.Home;
            Services.Content = CommonStrings.Services;
            Excursions.Content = CommonStrings.Excursions;
            History.Content = CommonStrings.History;
            News.Content = CommonStrings.News;
            Contacts.Content = CommonStrings.Contacts;
            MainText.Text = CommonStrings.MainText;
            LanguageButton.Content = CurrentCulture.ToUpper();
        }

        private void UpdateLocalization()
        {
            if (CurrentCulture == "ru")
                CurrentCulture = "sr";
            else if (CurrentCulture == "sr")
                CurrentCulture = "en";
            else
                CurrentCulture = "ru";
            Thread.CurrentThread.CurrentUICulture = new System.Globalization.CultureInfo(CurrentCulture);
        }

        private void LanguageButton_Click(object sender, RoutedEventArgs e)
        {
            UpdateLocalization();
            UpdateUI();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateUI();
        }
    }
}
